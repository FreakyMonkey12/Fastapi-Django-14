import smtplib
from email.mime.text import MIMEText

def send_email(subject: str, recipient: str, body: str):
    sender = "you@example.com"
    msg = MIMEText(body)
    msg["Subject"] = subject
    msg["From"] = sender
    msg["To"] = recipient

    with smtplib.SMTP("localhost") as server:
        server.sendmail(sender, [recipient], msg.as_string())
