import unittest
from app import crud, models, schemas

class TestCRUD(unittest.TestCase):
    def test_create_contact(self):
        # Пример теста создания контакта
        pass

    def test_get_contact(self):
        # Пример теста получения контакта
        pass

if __name__ == '__main__':
    unittest.main()
